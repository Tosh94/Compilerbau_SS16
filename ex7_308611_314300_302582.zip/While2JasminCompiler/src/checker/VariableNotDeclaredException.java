package checker;

public class VariableNotDeclaredException extends Exception {

	private static final long serialVersionUID = 1L;

	public VariableNotDeclaredException(String s) {
		super(s);
	}

}
