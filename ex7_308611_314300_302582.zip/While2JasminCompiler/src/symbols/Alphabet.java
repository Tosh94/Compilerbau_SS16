package symbols;

/**
 * Interface for all symbols.
 */
public interface Alphabet {

}